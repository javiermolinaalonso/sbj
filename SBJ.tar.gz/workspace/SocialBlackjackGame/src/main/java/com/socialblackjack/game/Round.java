package com.socialblackjack.game;

public interface Round {

	/**
	 * Starts a new round of the current step
	 */
	public void startRound();
}

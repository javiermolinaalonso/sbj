package com.socialblackjack.game.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.socialblackjack.game.entities.Player;
import com.socialblackjack.hand.blackjack.BlackjackHand;

public class BlackjackGameImpl extends GameImpl {

	private Map<Player, List<BlackjackHand>> players;
	private Player[] seatPlayers;
	
	//private tablerules
	
	public BlackjackGameImpl(){
		players = new HashMap<Player, List<BlackjackHand>>();
		seatPlayers = new Player[6];
	}
	
	public Integer getCurrentPlayers() {
		int count = 0;
		for(Player p : seatPlayers) {
			if(p != null)
				count++;
		}
		return count;
	}

	public boolean isTableFull(){
		return getCurrentPlayers() >= 6; //TODO Use table rules
	}

	public void sitPlayer(Player player) {
		for(int i = 0; i < 6; i++){
			Player p = seatPlayers[i];
			if(p == null) {
				sitPlayer(player, i);
				return;
			}
		}
	}
	
	public void sitPlayer(Player player, Integer position){
		this.seatPlayers[position] = player;
	}
}

package com.socialblackjack.game.entities;


public class Table {

	public static int maxPlayers = 6;
	
	private String name;
	private Float minimumBet;
	private Float maximumBet;
	
	public Table(String name, Float minimumBet, Float maximumBet) {
		super();
		this.name = name;
		this.minimumBet = minimumBet;
		this.maximumBet = maximumBet;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getMinimumBet() {
		return minimumBet;
	}
	public void setMinimumBet(Float minimumBet) {
		this.minimumBet = minimumBet;
	}
	public Float getMaximumBet() {
		return maximumBet;
	}
	public void setMaximumBet(Float maximumBet) {
		this.maximumBet = maximumBet;
	}
}

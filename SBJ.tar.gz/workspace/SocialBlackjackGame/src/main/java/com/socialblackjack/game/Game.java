package com.socialblackjack.game;

import com.socialblackjack.game.entities.Player;

public interface Game {

	/**
	 * Returns the players that are playing at the current round
	 * @return
	 */
	public Integer getCurrentPlayers();
	
	/**
	 * Return true if all the seats are occupied, false otherwise
	 * @return
	 */
	public boolean isTableFull();
	
	/**
	 * Sits the player at random free position
	 * @param player
	 */
	public void sitPlayer(Player player);
}

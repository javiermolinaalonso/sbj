package com.socialblackjack.game.impl;

import com.socialblackjack.game.Game;

public abstract class GameImpl implements Game {

}

package com.socialblackjack.game.entities;

public class Player {

	private String name;
	private Float coins;
	
	public Player(String name, Float coins){
		this.name = name;
		this.coins = coins;
	}
	
	public void doTakeMoney(Float amount){
		this.coins -= amount;
	}
	
	public void doAddMoney(Float amount){
		this.coins += amount;
	}
	
	public Float getCoins() {
		return coins;
	}

	public String getName() {
		return name;
	}
}

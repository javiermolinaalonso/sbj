package com.test

object Wachap {

  def main(args: Array[String]): Unit = {
    println("I rock");
  }

}
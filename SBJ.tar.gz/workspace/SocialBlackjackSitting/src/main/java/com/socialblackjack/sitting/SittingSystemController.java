package com.socialblackjack.sitting;

import com.socialblackjack.game.entities.Player;
import com.socialblackjack.sitting.exceptions.MaximumSeatsException;

/**
 * This class is the controller for one table instance which is 
 * autowired.
 * @author javi
 *
 */
public interface SittingSystemController {

	/**
	 * Attemps to seat the player to the current table
	 * If there are seats available then it will sit and change 
	 * the status to SITTING, else it will change the status to
	 * WAITING
	 * @param player
	 */
	public void attemptSeat(Player player);
	
	/**
	 * Sits the player to the current table.
	 * Change the player status to SITTING
	 * @param player
	 */
	public void sit(Player player) throws MaximumSeatsException;
	
	/**
	 * Sits all the players that are in SITTING status
	 */
	public void sit();
	
	/**
	 * Sits out the player on the beggining of the next round
	 * @param player
	 */
	public void sitout(Player player);
	
	/**
	 * Adds the player to the waiting list
	 * @param player
	 */
	public void wait(Player player);
	
	/**
	 * Cancels the sitout player status, returns to PLAYING game
	 * @param player
	 */
	public void cancelSitout(Player player);
	
	/**
	 * Removes the player from the table at the beggining of the next round.
	 * Add the player to "leave" status
	 * @param player
	 */
	public void leave(Player player);

	/**
	 * Removes all the players that are in leave status
	 */
	public void leave();
	
}

package com.socialblackjack.sitting;

public enum SittingStatus {

	WAITING, SITTING, PLAYING, SITTINGOUT, LEAVING, WATCHING
	
}

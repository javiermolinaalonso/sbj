package com.socialblackjack.sitting.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.socialblackjack.game.Game;
import com.socialblackjack.game.Round;
import com.socialblackjack.game.entities.Player;
import com.socialblackjack.sitting.SittingSystemController;
import com.socialblackjack.sitting.exceptions.MaximumSeatsException;

public class SittingSystemControllerImpl implements SittingSystemController, Round{

	private Game game;
	private Queue<Player> queuePlayers;
	private List<Player> playingPlayers;
	private List<Player> sitOutPlayers;
	private Set<Player> watchingPlayers;
	
	public SittingSystemControllerImpl() {
		queuePlayers = new ConcurrentLinkedQueue<Player>();
		playingPlayers = new ArrayList<Player>();
		sitOutPlayers = new ArrayList<Player>();
		watchingPlayers = new HashSet<Player>();
	}
	public void startRound() {
		leave();
		sit();
	}

	public void attemptSeat(Player player) {
		if(game.isTableFull()){
			queuePlayers.add(player);
		}else{
			sit(player);
		}
	}

	public void sit(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void sit() {
		// TODO Auto-generated method stub
		
	}

	public void sitout(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void wait(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void cancelSitout(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void leave(Player player) {
		// TODO Auto-generated method stub
		
	}

	public void leave() {
		// TODO Auto-generated method stub
		
	}

}

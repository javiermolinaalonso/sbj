package com.socialblackjack.sitting.exceptions;

public class MaximumSeatsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7046875397522439313L;

}

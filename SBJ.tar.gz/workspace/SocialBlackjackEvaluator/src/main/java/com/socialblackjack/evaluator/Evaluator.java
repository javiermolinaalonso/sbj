package com.socialblackjack.evaluator;

public interface Evaluator {

	public void evaluate();
}

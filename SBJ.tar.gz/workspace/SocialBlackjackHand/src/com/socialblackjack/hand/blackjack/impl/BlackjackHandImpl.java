package com.socialblackjack.hand.blackjack.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.socialblackjack.core.Card;
import com.socialblackjack.core.exceptions.MaximumCardsReached;
import com.socialblackjack.hand.blackjack.BlackjackHand;
import com.socialblackjack.hand.blackjack.utils.HandUtils;

public class BlackjackHandImpl implements BlackjackHand {

	private List<Card> cards;
	
	public void addCard(Card card) throws MaximumCardsReached {
		if(cards == null)
			cards = new ArrayList<Card>();
		if(cards.size() == MAX_CARDS)
			throw new MaximumCardsReached();
		cards.add(card);
	}

	public <T extends Number> Integer getHigherValue() {
		Integer max = 0;
		for(Integer v : getValues()){
			max = Math.max(max, v);
		}
		return max;
	}

	@SuppressWarnings("unchecked")
	public Collection<Integer> getValues() {
		if(cards == null)
			return new ArrayList<Integer>();
		//TODO TEST THIS!!!! VERY IMPORTANT
		LinkedList<Integer> currentValidResults = new LinkedList<Integer>();
		currentValidResults.add(0);
		for(Card card : cards){
			List<Integer> auxList = (List<Integer>) currentValidResults.clone();
			currentValidResults.clear();
			for(Integer curValue : HandUtils.getValuesFromRank(card.getRank())){
				for(Integer acumValue : auxList){
					currentValidResults.add(acumValue+curValue);
				}
			}
		}
		Iterator<Integer> it = currentValidResults.iterator();
		while(it.hasNext()){
			if(currentValidResults.size() == 1)
				break;
			if(it.next() > MAX_VALUE){
				it.remove();
			}
		}
		return currentValidResults;
	}

	public Collection<Card> getShowableCards() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<Card> getHideCards() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<Card> getCards() {
		return cards;
	}

	public boolean isBlackjack() {
		return MAX_VALUE.equals(getHigherValue()) && cards.size() == 2;
	}

	public boolean isSplittable() {
		return cards.size() == 2 && (cards.get(0).getRankValue().equals(cards.get(1).getRankValue()) || cards.get(0).getRankValue() >= 10 && cards.get(1).getRankValue() >= 10);
	}

	public boolean isBust() {
		return getHigherValue() > MAX_VALUE;
	}

	public boolean isSoft() {
		return cards.get(0).getRank().equals("A") || cards.get(1).getRank().equals("A");
	}

	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer();
		for(Card c : cards){
			sb.append(c.getValue());
		}
		return sb.toString();
	}
}

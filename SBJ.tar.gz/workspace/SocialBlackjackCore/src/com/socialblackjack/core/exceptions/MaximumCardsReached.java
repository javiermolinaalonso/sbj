package com.socialblackjack.core.exceptions;

public class MaximumCardsReached extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5358108961664824245L;

}

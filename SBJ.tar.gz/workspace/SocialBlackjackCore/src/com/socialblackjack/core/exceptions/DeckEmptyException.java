package com.socialblackjack.core.exceptions;

public class DeckEmptyException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3502042168135082116L;

}

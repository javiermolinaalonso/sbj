package com.socialblackjack.core.impl;

import com.socialblackjack.core.Card;

public class CardImpl implements Card {

	private byte card;
	
	public CardImpl(byte card){
		this.card = card;
	}
	
	public byte getCard() {
		return card;
	}

	public Integer getRankValue() {
		return card % 13;
	}

	public String getRank() {
		return String.valueOf(RANKS[card % 13]);
	}

	public String getColor() {
		return String.valueOf(COLORS[card / 13 % 4]);
	}

	public String getValue() {
		StringBuilder sb = new StringBuilder();
		sb.append(RANKS[card % 13]).append(COLORS[card / 13 % 4]);
		return sb.toString();
	}

}
